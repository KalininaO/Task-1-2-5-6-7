btn.addEventListener("click", res_out);

   function res_out (){
       q = Number(a.value) + Number(b.value) - Number(c.value) + Number(d.value) - Number(e.value);
       res.innerHTML = q;
   }