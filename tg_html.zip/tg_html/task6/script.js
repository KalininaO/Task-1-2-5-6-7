btn.addEventListener("click", f);
btn1.addEventListener("click", f1);
function f (){
    console.log(ans1.checked);
    console.log(ans2.checked);
    console.log(ans3.checked);
    console.log(ans4.checked);

    if (ans1.checked){
        right.classList.remove("hdn");
        wrong.classList.add("hdn");
        alert("ПОЗДРАВЛЯЕМ (Ответ верный!)");
    }else{
        right.classList.add("hdn");
        wrong.classList.remove("hdn");
        alert("НЕПРАВИЛЬНО (Подумай еще!)");
    }

}
function f1 (){
    answer.classList.toggle("hdn");
    btn1.classList.toggle("opend");
}
